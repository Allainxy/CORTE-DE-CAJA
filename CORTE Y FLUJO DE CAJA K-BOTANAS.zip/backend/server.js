// server.js — API REST para K-BOTANAS
const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'kbot-cambia-este-secreto-' + Math.random();
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'kbotanas.db');

const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use((req, _res, next) => { console.log(new Date().toISOString(), req.method, req.url); next(); });

// ---------- Auth middleware ----------
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Token requerido' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido' });
  }
}

// ---------- Login ----------
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Faltan credenciales' });
  const u = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!u || !bcrypt.compareSync(password, u.password))
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
  const token = jwt.sign({ id: u.id, username: u.username, rol: u.rol, nombre: u.nombre }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: { id: u.id, username: u.username, nombre: u.nombre, rol: u.rol } });
});

app.get('/api/me', auth, (req, res) => res.json({ user: req.user }));

// ---------- Movimientos ----------
app.get('/api/movs', auth, (_req, res) => {
  const rows = db.prepare('SELECT * FROM movs WHERE deleted = 0 ORDER BY fecha DESC').all();
  res.json({ movs: rows });
});

app.post('/api/movs', auth, (req, res) => {
  const m = req.body;
  if (!m?.id || !m.fecha || !m.tipo) return res.status(400).json({ error: 'Datos incompletos' });
  const now = Date.now();
  db.prepare(`INSERT INTO movs (id, fecha, tipo, categoria, concepto, monto, metodo, caja, usuario, notas, src, user_id, updated_at, deleted)
    VALUES (@id, @fecha, @tipo, @categoria, @concepto, @monto, @metodo, @caja, @usuario, @notas, @src, @user_id, @updated_at, 0)
    ON CONFLICT(id) DO UPDATE SET
      fecha=@fecha, tipo=@tipo, categoria=@categoria, concepto=@concepto, monto=@monto,
      metodo=@metodo, caja=@caja, usuario=@usuario, notas=@notas, src=@src, updated_at=@updated_at, deleted=0`).run({
    id: m.id, fecha: m.fecha, tipo: m.tipo, categoria: m.categoria || '',
    concepto: m.concepto || '', monto: Number(m.monto) || 0,
    metodo: m.metodo || 'EFECTIVO', caja: m.caja || 'PRINCIPAL',
    usuario: m.usuario || req.user.nombre, notas: m.notas || '',
    src: m.src || 'manual', user_id: req.user.id, updated_at: now
  });
  res.json({ ok: true, id: m.id });
});

app.post('/api/movs/bulk', auth, (req, res) => {
  const items = req.body?.items;
  if (!Array.isArray(items)) return res.status(400).json({ error: 'items requerido' });
  const now = Date.now();
  const stmt = db.prepare(`INSERT INTO movs (id, fecha, tipo, categoria, concepto, monto, metodo, caja, usuario, notas, src, user_id, updated_at, deleted)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    ON CONFLICT(id) DO UPDATE SET fecha=excluded.fecha, tipo=excluded.tipo, categoria=excluded.categoria,
      concepto=excluded.concepto, monto=excluded.monto, metodo=excluded.metodo, caja=excluded.caja,
      usuario=excluded.usuario, notas=excluded.notas, src=excluded.src, updated_at=excluded.updated_at, deleted=0`);
  const tx = db.transaction((arr) => {
    for (const m of arr) {
      stmt.run(m.id, m.fecha, m.tipo, m.categoria || '', m.concepto || '', Number(m.monto) || 0,
        m.metodo || 'EFECTIVO', m.caja || 'PRINCIPAL', m.usuario || req.user.nombre,
        m.notas || '', m.src || 'xml', req.user.id, now);
    }
  });
  tx(items);
  res.json({ ok: true, count: items.length });
});

app.delete('/api/movs/:id', auth, (req, res) => {
  db.prepare('UPDATE movs SET deleted = 1, updated_at = ? WHERE id = ?').run(Date.now(), req.params.id);
  res.json({ ok: true });
});

// ---------- Categorías ----------
app.get('/api/cats', auth, (_req, res) => {
  res.json({ cats: db.prepare('SELECT * FROM cats WHERE deleted = 0').all() });
});

app.post('/api/cats', auth, (req, res) => {
  const c = req.body;
  if (!c?.id || !c.nombre) return res.status(400).json({ error: 'Datos incompletos' });
  db.prepare(`INSERT INTO cats (id, tipo, nombre, color, icon, updated_at, deleted) VALUES (?, ?, ?, ?, ?, ?, 0)
    ON CONFLICT(id) DO UPDATE SET tipo=excluded.tipo, nombre=excluded.nombre, color=excluded.color, icon=excluded.icon, updated_at=excluded.updated_at, deleted=0`)
    .run(c.id, c.tipo, c.nombre, c.color || '', c.icon || '', Date.now());
  res.json({ ok: true });
});

app.delete('/api/cats/:id', auth, (req, res) => {
  db.prepare('UPDATE cats SET deleted = 1, updated_at = ? WHERE id = ?').run(Date.now(), req.params.id);
  res.json({ ok: true });
});

// ---------- Presupuestos ----------
app.get('/api/budgets', auth, (_req, res) => {
  res.json({ budgets: db.prepare('SELECT * FROM budgets').all() });
});

app.post('/api/budgets', auth, (req, res) => {
  const b = req.body;
  if (!b?.id) return res.status(400).json({ error: 'id requerido' });
  db.prepare(`INSERT INTO budgets (id, monto, updated_at) VALUES (?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET monto=excluded.monto, updated_at=excluded.updated_at`)
    .run(b.id, Number(b.monto) || 0, Date.now());
  res.json({ ok: true });
});

// ---------- Sync incremental ----------
app.get('/api/sync', auth, (req, res) => {
  const since = parseInt(req.query.since) || 0;
  res.json({
    movs: db.prepare('SELECT * FROM movs WHERE updated_at > ?').all(since),
    cats: db.prepare('SELECT * FROM cats WHERE updated_at > ?').all(since),
    budgets: db.prepare('SELECT * FROM budgets WHERE updated_at > ?').all(since),
    serverTime: Date.now()
  });
});

app.get('/', (_req, res) => res.json({ ok: true, name: 'K-BOTANAS API', version: '1.0' }));

app.listen(PORT, () => {
  console.log(`🌶️  K-BOTANAS API corriendo en http://localhost:${PORT}`);
  console.log(`   Base de datos: ${DB_FILE}`);
});
